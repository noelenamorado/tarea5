/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 *
 */
public class Main {
    public static void main(String[] args) {
        Formas[] formas = {
            new Circulo(5),
            new Cuadrado(4),
            new Triangulo(3, 4),
            new Rectangulo(5, 6)
        };

        for (Formas forma : formas) {
            forma.dibujar();
            System.out.println("Área: " + forma.area());
            System.out.println("Perímetro: " + forma.perimetro());
            System.out.println();
        }
    }
}
